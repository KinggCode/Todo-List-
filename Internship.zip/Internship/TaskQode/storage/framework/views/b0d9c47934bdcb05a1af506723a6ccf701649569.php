<?php $__env->startSection('title', 'TaskQode - Dashboard'); ?>


<?php $__env->startSection('content'); ?>

<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="<?php echo e(route('user.users.show',Auth::user()->id)); ?>">Profile</a></li>
    <li class="breadcrumb-item active" aria-current="page"><?php echo e($user->name); ?></li>
    </ol>
  </nav>

<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12">
        <div class="card">
            <div class="card-body shadow-lg">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="card">
                            <div class="card-body">
                                <form class="my-5" action="<?php echo e(route('user.users.update',Auth::user()->id)); ?>"  method="POST" >
                                   <?php echo method_field('PATCH'); ?>
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                      <label for="exampleInputEmail1">Full name</label>
                                      <input type="text" class="form-control" name="name" value="<?php echo e($user->name ?? 'N/A'); ?>">
                                      <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <small style="color:red;"><?php echo e($errors->first('title')); ?></small>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Username</label>
                                        <input type="text" class="form-control" name="username" value="<?php echo e($user->username ?? ' '); ?>">

                                      </div>
                                      <div class="form-group">
                                        <label for="exampleInputEmail1">Email address</label>
                                        <input type="email" class="form-control" name="email" aria-describedby="emailHelp" value="<?php echo e($user->email ?? 'N/A'); ?>">
                                        <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small style="color:red;"><?php echo e($errors->first('email')); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                      <div class="form-group">
                                        <label for="exampleInputEmail1">Pin</label>
                                        <input type="text" class="form-control" name="pin" value="<?php echo e($user->pin ?? ''); ?>">
                                        <?php $__errorArgs = ['pin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small style="color:red;"><?php echo e($errors->first('pin')); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                      <label for="exampleInputPassword1">Password</label>
                                      <input type="password" class="form-control" name="password" value="<?php echo e($user->password ?? ''); ?>">
                                      <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <small style="color:red;"><?php echo e($errors->first('password')); ?></small>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>



                            </div>
                        </div>
                    </div>



                <div class="col-lg-6 col-sm-6 col-md-6">
                        <div class="form-group">
                          <label for="exampleInputEmail1">Gender</label>
                          <input type="text" class="form-control" name="gender" aria-describedby="emailHelp" value="<?php echo e($user->gender  ?? '-'); ?>">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Phone</label>
                            <input type="text" class="form-control" name="phone" aria-describedby="emailHelp" value="<?php echo e($user->phone ?? '00000000'); ?>">
                          </div>

                        <div class="form-group">
                            <label for="exampleInputEmail1">Country</label>
                            <input type="text" class="form-control" name="country" aria-describedby="emailHelp" value="<?php echo e($user->country ?? ''); ?>">
                          </div>
                          <div class="form-group">
                            <label for="exampleInputEmail1">City</label>
                            <input type="text" class="form-control" name="city" aria-describedby="emailHelp" value="<?php echo e($user->city ?? ''); ?>">
                          </div>

                          <div class="form-group">
                              <p>Last updated: <?php echo e($user->updated_at); ?></p>
                              <p>Status: Online</p>
                              <p>Access Code: Ask Admin for access</p>
                          </div>

                        <button type="submit" class="btn btn-primary">Submit</button>
                      </form>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.essentials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/work/Desktop/grand_finale/Internship/TaskQode/resources/views/users/accounts/edit.blade.php ENDPATH**/ ?>