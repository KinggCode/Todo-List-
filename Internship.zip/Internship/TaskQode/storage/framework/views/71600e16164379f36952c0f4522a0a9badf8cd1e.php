<div class="row">
    <div class="col-lg-12 col-md-12">
        <a  href="/" class="btn btn-outline-secondary " style="margin:2rem 2rem">  <?php echo $__env->yieldContent('name'); ?> </a>
    </div>
</div>
<?php /**PATH /Users/work/Desktop/grand_finale/Internship/TaskQode/resources/views/users/essentials/home-link.blade.php ENDPATH**/ ?>