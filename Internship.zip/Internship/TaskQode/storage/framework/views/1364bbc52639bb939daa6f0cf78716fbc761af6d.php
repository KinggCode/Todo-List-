        


        <?php $__env->startSection('content'); ?>
        <div class="flex-center position-ref full-height">
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(route('user.users.show',Auth::user()->id)); ?>"><?php echo e(Auth::user()->name); ?></a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>">Login</a>

                        <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>">Register</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="content">
                <div class="title m-b-md">
                   TaskQode.
                </div>

                <div class="links">
                    <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('user.users.show',Auth::user()->id)); ?>">Profile</a>
                    <a href="<?php echo e(route('user.tasks.index',Auth::user()->id)); ?>">Tasks</a>
                    <?php else: ?>
                    <a href="/splash">It's begins with you.</a>

                    <?php endif; ?>

                </div>
            </div>
        </div>
        <?php $__env->stopSection(); ?>


<?php echo $__env->make('users.essentials.splash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/work/Desktop/grand_finale/Internship/TaskQode/resources/views/welcome.blade.php ENDPATH**/ ?>