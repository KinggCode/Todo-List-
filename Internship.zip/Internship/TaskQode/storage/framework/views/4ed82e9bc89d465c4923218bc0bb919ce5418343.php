<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" >
    <a class="navbar-brand" href="/">TaskQode.</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">

        
      <ul class="navbar-nav ml-auto">
        

        <li class="nav-item ">
          <a class="nav-link" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
           Task Management
          </a>

        </li>


        <li class="nav-item dropdown inner-element">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <img src="<?php echo e(asset('images/default.jpeg')); ?>" alt="" class="rounded-circle profile-img">
            </a>
            <div class="dropdown-menu drop-nav" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="#">Profile</a>
              <a class="dropdown-item" href="#">Settings</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item  btn btn-danger" href="<?php echo e(route('logout')); ?>"
                onclick="event.preventDefault();
                                         document.getElementById('logout-form').submit();"><i class="fa fa-power -off"></i>Logout</a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
            </div>



          </li>
      </ul>

    </div>

  </nav>
<?php /**PATH /Users/work/Desktop/grand_finale/Internship/TaskQode/resources/views/users/essentials/navbar.blade.php ENDPATH**/ ?>