<?php $__env->startSection('title', 'TaskQode - Dashboard'); ?>



<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12">
        <div class="card">
            <div class="card-body shadow-lg">
                <div class="row">
                    <div class="col-lg-12">
                        <h3>Task</h3>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="row">
                            <div class="col-3">
                              <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                                <a class="nav-link active" id="v-pills-home-tab" data-toggle="pill" href="#v-pills-home" role="tab" aria-controls="v-pills-home" aria-selected="true"><?php echo e($task->title); ?></a>
                                <a class="nav-link" id="v-pills-profile-tab" data-toggle="pill" href="#v-pills-profile" role="tab" aria-controls="v-pills-profile" aria-selected="false">Edit</a>
                                
                                <a href="<?php echo e(route('user.tasks.dash',Auth::user()->id)); ?>" class="nav-link btn btn-outline-secondary my-3">Back to Tasks</a>
                              </div>
                            </div>
                            <div class="col-9">
                              <div class="tab-content" id="v-pills-tabContent">
                                <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
                                    <ul class="list-group">
                                        <li class="list-group-item"> <strong><span>Description: </span></strong><?php echo e($task->description); ?></li>
                                        <li class="list-group-item"><strong><span>Start: </span></strong><?php echo e($task->start); ?></li>
                                        <li class="list-group-item"><strong><span>End: </span></strong><?php echo e($task->end); ?></li>
                                        <li class="list-group-item"><strong><span>Level: </span></strong><?php echo e($task->level); ?></li>
                                      </ul>
                                </div>
                                <div class="tab-pane fade" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <form method="POST" action="<?php echo e(route('user.tasks.update',Auth::user()->id)); ?>">
                                                <?php echo method_field('PATCH'); ?>
                                                <?php echo csrf_field(); ?>
                                                <div class="form-group">
                                                  <label for="exampleInputEmail1">Title</label>
                                                  <input type="text" class="form-control" name="title" value="<?php echo e($task->title); ?>">
                                                </div>
                                                <div class="form-group">
                                                  <label for="exampleInputPassword1">Description</label>
                                                  <input type="text" class="form-control" name="description" value="<?php echo e($task->description); ?>" >
                                                </div>
                                                <div class="form-group">
                                                    <label for="exampleInputPassword1">Start Date</label>
                                                    <input type="date" class="form-control" name="start" value="<?php echo e($task->start); ?>" >
                                                  </div>
                                                  <div class="form-group">
                                                    <label for="exampleInputPassword1">End Date</label>
                                                    <input type="date" class="form-control" name="end" value="<?php echo e($task->end); ?>">
                                                  </div>

                                                  <div class="form-group">
                                                    <label for="exampleFormControlSelect1">Level</label>
                                                    <select class="form-control" name="level" id="exampleFormControlSelect1">
                                                      <option value="primary">Not Important</option>
                                                      <option value="secondary">Little Important</option>
                                                      <option value="warning">Important</option>
                                                      <option value="success">Very Important</option>
                                                      <option value="danger">Need to achieve</option>
                                                    </select>
                                                  </div>
                                                  
                                                  <button type="submit" class="btn btn-warning">Edit <?php echo e($task->title); ?></button>
                                                </form>

                                        </div>

                                        <div class="col-lg-6">


                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="v-pills-messages" role="tabpanel" aria-labelledby="v-pills-messages-tab">...</div>
                                <div class="tab-pane fade" id="v-pills-settings" role="tabpanel" aria-labelledby="v-pills-settings-tab">...</div>
                              </div>
                            </div>
                          </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.essentials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/work/Desktop/grand_finale/Internship/TaskQode/resources/views/users/tasks/show.blade.php ENDPATH**/ ?>