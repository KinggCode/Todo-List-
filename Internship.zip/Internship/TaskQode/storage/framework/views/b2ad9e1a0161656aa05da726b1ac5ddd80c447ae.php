<!doctype html>
<html  lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <?php echo $__env->make('users.essentials.links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>

    <!-- Right Panel -->

    <div id="lockscreen" class="lockscreen">

        <?php echo $__env->yieldContent('message'); ?>


        <?php if(session()->has('success')): ?>
          <div class="alert alert-success " role="alert">
            <strong>Success: </strong> <span><?php echo e(session()->get('message')); ?></span>
            </div>
          <?php endif; ?>

          <?php if(session()->has('error')): ?>
          <div class="alert alert-danger" role="alert">
            <strong>Warning : </strong> <span><?php echo e(session()->get('error')); ?></span>
             </div>
          <?php endif; ?>


        <?php echo $__env->yieldContent('content'); ?>

    </div>

   <?php echo $__env->make('users.essentials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH /Users/work/Desktop/grand_finale/Internship/TaskQode/resources/views/users/essentials/splash.blade.php ENDPATH**/ ?>