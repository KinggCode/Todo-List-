<?php $__env->startSection('title', 'TaskQode - Dashboard'); ?>

<?php $__env->startSection('message'); ?>
<div class="jumbotron jumbotron-fluid">
    <div class="container">
      <h1 class="display-4">Welcome <?php echo e($user->name); ?></h1>
      <p class="lead">To get started visit your profile for instructions. <span><a href="<?php echo e(route('user.users.show',Auth::user()->id)); ?>">Profile</a></span></p>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card my-3">
            <div class="card-body shadow-lg">

                <div class="row">
                    <div class="col-lg-12">
                        <h2 class="ml-4">TaskQode</h2>
                    </div>
                </div>
                <div class="row panel">
                    <div class="col-lg-5 col-md-5" >
                        <div class="card">
                            <div class="card-body shadow-lg">
                                <form method="POST" action="<?php echo e(route('user.tasks.store',Auth::user()->id)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                      <label for="exampleInputEmail1">Title</label>
                                      <input type="text"title name="title" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                                      <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <small style="color:red;"><?php echo e($errors->first('title')); ?></small>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label for="exampleFormControlSelect1">Level</label>
                                        <select class="form-control" name="level" id="exampleFormControlSelect1">
                                          <option value="primary">Not Important</option>
                                          <option value="secondary">Little Important</option>
                                          <option value="warning">Important</option>
                                          <option value="success">Very Important</option>
                                          <option value="danger">Need to achieve</option>
                                        </select>
                                      </div>

                                      <div class="form-group">
                                        <label for="exampleFormControlTextarea1">Description</label>
                                        <textarea class="form-control" name="description" id="exampleFormControlTextarea1" rows="5"></textarea>
                                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small style="color:red;"><?php echo e($errors->first('description')); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>


                            </div>
                        </div>

                    </div>

                    <div class="col-lg-7 col-md-7">
                        <div class="card">
                            <div class="card-body shadow-lg">
                                  



                                      <div class="form-group">
                                        <label for="exampleInputPassword1">Start Date</label>
                                        <input type="date" name="start" class="form-control" id="exampleInputPassword1">
                                        <?php $__errorArgs = ['start'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small style="color:red;"><?php echo e($errors->first('start')); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                      <div class="form-group">
                                        <label for="exampleInputPassword1">End Date</label>
                                        <input type="date" name="end" class="form-control" id="exampleInputPassword1">
                                        <?php $__errorArgs = ['end'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small style="color:red;"><?php echo e($errors->first('end')); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">

                                    <button type="submit" class="btn btn-primary">Submit</button>
                                  </form>
                            </div>
                        </div>

                    </div>
                </div>
            </div>


        </div>
    </div>
</div>


<div class="row">
    <div class="col-lg-12 col-md-12">
        <div class="card">
            <div class="card-body shadow-lg">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="card">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-lg-12 col-sm-12 col-md-12">
                                        <h4 class="my-4">To to list</h4>
                                    </div>
                                </div>
                                <div class="list-group">

                                    <?php if(isset($tasks)): ?>

                                    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e(route('user.tasks.show',$task->id)); ?>" class="list-group-item list-group-item-action a<?php echo e($task->level); ?>">
                                        <div class="d-flex w-100 justify-content-between">
                                          <h5 class="mb-1"><?php echo e($task->title); ?></h5>
                                          <small><?php echo e($task->created_at); ?></small>
                                        </div>
                                        <p class="mb-1"><?php echo e($task->description); ?></p>
                                        <small><strong><span>Start Date: </span></strong> <?php echo e($task->start); ?></small>
                                        <small><strong><span>End Date: </span></strong> <?php echo e($task->start); ?></small>
                                      </a>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    <?php endif; ?>

                                    <?php if(isset($tasks) !== null && isset($tasks) == null ): ?>
                                      <a class="list-group-item">No record found</a>

                                    <?php endif; ?>


                                  </div>

                                  <div class="row">
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <a href="<?php echo e(route('user.tasks.index')); ?>" class="btn btn-outline-info my-3 text-center">View More</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="card">
                            <div class="card-body shadow-lg">
                                <div class="row">
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <h3>Tasks Chart</h3>

                                        <div class="card">
                                            <div class="card-body">

                                                    <input type="hidden" id="danger" value="<?php echo e($danger); ?>">
                                                    <input type="hidden" id="success" value="<?php echo e($success); ?>">
                                                    <input type="hidden" id="secondary" value="<?php echo e($secondary); ?>">
                                                    <input type="hidden" id="primary" value="<?php echo e($primary); ?>">
                                                    <input type="hidden" id="dark" value="<?php echo e($dark); ?>">
                                                    <input type="hidden" id="warning" value="<?php echo e($warning); ?>">
                                                    <canvas id="tasksChart" width="100%" height="30"> </canvas>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.essentials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/work/Desktop/grand_finale/Internship/TaskQode/resources/views/users/tasks/dashboard.blade.php ENDPATH**/ ?>