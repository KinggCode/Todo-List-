<aside id="left-panel" class="left-panel">
    <nav class="navbar navbar-expand-lg navbar-light bg-light">


        <div class="collapse navbar-collapse" class="sidebar" id="sidebar">
          <ul class="navbar-nav">


            <li >
              <a  href="#">Home <span class="sr-only">(current)</span></a>
            </li>


            <li>
              <a  href="#">Link</a>
            </li>


            <li class="nav-item dropdown">
              <a class="dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Dropdown
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="#">Action</a>
                <a class="dropdown-item" href="#">Another action</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#">Something else here</a>
              </div>
            </li>


            <li >
              <a class=" disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
            </li>


          </ul>



        </div>
      </nav>
</aside>
  
<?php /**PATH /Users/work/Desktop/grand_finale/Internship/TaskQode/resources/views/users/essentials/sidebar.blade.php ENDPATH**/ ?>