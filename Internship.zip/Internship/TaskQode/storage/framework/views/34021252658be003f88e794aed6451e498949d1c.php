<?php $__env->startSection('title', 'TaskQode - Dashboard'); ?>


<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12">
        <div class="card my-3">
            <div class="card-body shadow-lg">

                <div class="row">
                    <div class="col-lg-12">
                        <h2 class="ml-4">TaskQode</h2>
                    </div>
                </div>
                <div class="row panel">
                    <div class="col-lg-5 col-md-5" >
                        <div class="card">
                            <div class="card-body shadow-lg">
                                <form method="POST" action="#">
                                    <div class="form-group">
                                      <label for="exampleInputEmail1">Title</label>
                                      <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                                    </div>

                                    <div class="form-group">
                                        <label for="exampleFormControlSelect1">Level</label>
                                        <select class="form-control" id="exampleFormControlSelect1">
                                          <option value="">Not Important</option>
                                          <option value="">Little Important</option>
                                          <option value="">Important</option>
                                          <option value="">Very Important</option>
                                          <option value="">Need to achieve</option>
                                        </select>
                                      </div>

                                      <div class="form-group">
                                        <label for="exampleFormControlTextarea1">Description</label>
                                        <textarea class="form-control" id="exampleFormControlTextarea1" rows="5"></textarea>
                                      </div>


                            </div>
                        </div>

                    </div>

                    <div class="col-lg-7 col-md-7">
                        <div class="card">
                            <div class="card-body shadow-lg">
                                  



                                      <div class="form-group">
                                        <label for="exampleInputPassword1">Start Date</label>
                                        <input type="date" class="form-control" id="exampleInputPassword1">
                                      </div>

                                      <div class="form-group">
                                        <label for="exampleInputPassword1">End Date</label>
                                        <input type="date" class="form-control" id="exampleInputPassword1">
                                      </div>

                                    <button type="submit" class="btn btn-primary">Submit</button>
                                  </form>
                            </div>
                        </div>

                    </div>
                </div>
            </div>


        </div>
    </div>
</div>


<div class="row">
    <div class="col-lg-12 col-md-12">
        <div class="card">
            <div class="card-body shadow-lg">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="card">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-lg-12 col-sm-12 col-md-12">
                                        <h4 class="my-4">To to list</h4>
                                    </div>
                                </div>
                                <div class="list-group">
                                    <a href="#" class="list-group-item list-group-item-action adanger">
                                      <div class="d-flex w-100 justify-content-between">
                                        <h5 class="mb-1">List group item heading</h5>
                                        <small>3 days ago</small>
                                      </div>
                                      <p class="mb-1">Donec id elit non mi porta gravida at eget metus. Maecenas sed diam eget risus varius blandit.</p>
                                      <small>Donec id elit non mi porta.</small>
                                    </a>
                                    <a href="#" class="list-group-item list-group-item-action asuccess">
                                      <div class="d-flex w-100 justify-content-between">
                                        <h5 class="mb-1">List group item heading</h5>
                                        <small class="text-muted">3 days ago</small>
                                      </div>
                                      <p class="mb-1">Donec id elit non mi porta gravida at eget metus. Maecenas sed diam eget risus varius blandit.</p>
                                      <small class="text-muted">Donec id elit non mi porta.</small>
                                    </a>
                                    <a href="#" class="list-group-item list-group-item-action asecondary">
                                      <div class="d-flex w-100 justify-content-between">
                                        <h5 class="mb-1">List group item heading</h5>
                                        <small class="text-muted">3 days ago</small>
                                      </div>
                                      <p class="mb-1">Donec id elit non mi porta gravida at eget metus. Maecenas sed diam eget risus varius blandit.</p>
                                      <small class="text-muted">Donec id elit non mi porta.</small>
                                    </a>
                                  </div>

                                  <div class="row">
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <a class="btn btn-outline-info my-3 text-center">View More</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="card">
                            <div class="card-body shadow-lg">
                                <div class="row">
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <h3>Tasks Chart</h3>
                                        <form>
                                            <input type="hidden" value="">
                                            <input type="hidden" value="">
                                            <input type="hidden" value="">
                                            <input type="hidden" value="">
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.essentials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/work/Desktop/grand_finale/Internship/TaskQode/resources/views/users/general/dashboard.blade.php ENDPATH**/ ?>