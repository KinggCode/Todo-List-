<?php $__env->startSection('title','TaskQode  - User Registration'); ?>
<?php $__env->startSection('name','TaskQode'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('users.essentials.home-link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
    <div class="col-lg-6 col-md-5">
        <img src="https://images.pexels.com/photos/2495173/pexels-photo-2495173.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=500" alt="..." class="img-thumbnail border border-dark rounded-circle" style="margin-top:3rem; margin-left:5rem; width:35rem; height:35rem;">
    </div>
    <div class="col-lg-6 col-md-7">
    <div class="" style="margin-top: 2rem;">
        <div class="login-logo" >
            <h1 style="color: black;" class="has-text-weight-bold text-center mb-4">
               User Registration
            </h1>
            <p class="text-center" style="font-size: 0.8rem;">Register now, your journey begins here.</p>
        </div>

        <!-- Register container   -->
        <div class="login-form" style="margin-right:2rem;">
            <form method="POST" action="<?php echo e(url('/register')); ?>" aria-label="<?php echo e(__('Register')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label>Fullname</label>
                <input type="text" name="name" class="form-control" placeholder="Fullname" value="<?php echo e(old('name')); ?>">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small style="color:red;"><?php echo e($errors->first('name')); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label>Email address</label>
                    <input type="email" name="email" class="form-control" placeholder="Email" value="<?php echo e(old('email')); ?>">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small style="color:red;"><?php echo e($errors->first('email')); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" class="form-control" placeholder="Password" value="<?php echo e(old('password')); ?>">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small style="color:red;"><?php echo e($errors->first('password')); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label>Confirm Password</label>
                    <input type="password" name="password_confirmation" class="form-control" placeholder="Password" value="<?php echo e(old('password')); ?>">

                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small style="color:red;"><?php echo e($errors->first('password')); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label>Pin</label>
                    <input id="pin" type="text" class="form-control <?php $__errorArgs = ['pin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pin" value="<?php echo e(old('pin')); ?>" autocomplete="pin" autofocus>
                    <?php $__errorArgs = ['pin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>
                <div class="checkbox">
                    <label class="pull-right">
                        <a href="#">Forgotten Password?</a>
                    </label>

                </div>
                <button type="submit" name="user_reg_btn" class="btn btn-secondary btn-flat m-b-30 m-t-30">Sign Up</button>

                <div class="register-link m-t-15 text-center" style="margin-top: 2rem;">
                    <p>Already a member  ? <a href="<?php echo e(url('/login')); ?>"> Sign In Here</a></p>
                </div>
            </form>
        </div>
        <!-- Login Container ends -->
    </div>


    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/work/Desktop/grand_finale/Internship/TaskQode/resources/views/auth/register.blade.php ENDPATH**/ ?>