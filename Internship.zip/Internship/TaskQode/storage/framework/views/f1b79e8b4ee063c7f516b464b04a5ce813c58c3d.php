<?php $__env->startSection('title', 'TaskQode - Task Collection'); ?>


<?php $__env->startSection('content'); ?>

<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="<?php echo e(route('user.tasks.dash',Auth::user()->id)); ?>">Home</a></li>
      <li class="breadcrumb-item active" aria-current="page"><a > Tasks Collection</a></li>
    </ol>
  </nav>

<div class="row">
    <div class="col-lg-3">
        <div class="card mb-3" style="max-width: 540px;">
            <div class="row no-gutters widget">
              <div class="col-md-4">
                <img src="https://images.pexels.com/photos/32997/pexels-photo.jpg?auto=compress&cs=tinysrgb&dpr=2&w=500" class="card-img" alt="...">
              </div>
              <div class="col-md-8">
                <div class="card-body bg-secondary whitetext" >
                  <h5 class="card-title"><?php echo e($secondary); ?></h5>
                  <h3 class="card-text"><small >Not Important</small></h3>
                </div>
              </div>
            </div>
          </div>
    </div>
    <div class="col-lg-3">
        <div class="card mb-3" style="max-width: 540px;">
            <div class="row no-gutters widget">
              <div class="col-md-4 ">
                <img src="https://images.pexels.com/photos/32997/pexels-photo.jpg?auto=compress&cs=tinysrgb&dpr=2&w=500" class="card-img" alt="..." style="">
              </div>
              <div class="col-md-8">
                <div class="card-body bg-primary whitetext ">
                  <h5 class="card-title"><?php echo e($primary); ?></h5>
                  <h3 class="card-text"><small>Important</small></h3>
                </div>
              </div>
            </div>
          </div>
    </div>
    <div class="col-lg-3">
        <div class="card mb-3" style="max-width: 540px;">
            <div class="row no-gutters widget">
              <div class="col-md-4">
                <img src="https://images.pexels.com/photos/32997/pexels-photo.jpg?auto=compress&cs=tinysrgb&dpr=2&w=500" class="card-img" alt="...">
              </div>
              <div class="col-md-8">
                <div class="card-body bg-danger whitetext">
                  <h5 class="card-title"><?php echo e($danger); ?></h5>
                  <h3 class="card-text"><small>Need to achieve</small></h3>
                </div>
              </div>
            </div>
          </div>
    </div>
    <div class="col-lg-3">
        <div class="card mb-3" style="max-width: 540px;">
            <div class="row no-gutters widget">
              <div class="col-md-4">
                <img src="https://images.pexels.com/photos/32997/pexels-photo.jpg?auto=compress&cs=tinysrgb&dpr=2&w=500" class="card-img" alt="...">
              </div>
              <div class="col-md-8">
                <div class="card-body bg-success whitetext">
                  <h5 class="card-title"><?php echo e($success); ?></h5>
                  <h3 class="card-text"><small >Very Important</small></h3>
                </div>
              </div>
            </div>
          </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <h3 class="my-3">Tasks Collection</h3>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <table class="table table-hover">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Title</th>
                <th scope="col">Description</th>
                <th scope="col">Start</th>
                <th scope="col">Edit</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>

                <?php if(isset($tasks)): ?>
                <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="bg-">
                    <td><?php echo e($task->id); ?></td>
                    <td class="bg-<?php echo e($task->level); ?>"><?php echo e($task->title); ?></td>
                    <td><?php echo e($task->description); ?></td>
                    <td><?php echo e($task->start); ?></td>
                    <td><?php echo e($task->end); ?></td>
                    <td>
                        

                        <form action="<?php echo e(route('user.tasks.destroy',$task->id)); ?>" method="POST" class="my-3">
                            <?php echo method_field('DELETE'); ?>
                            <?php echo csrf_field(); ?>

                            <button type="submit" class="btn btn-outline-danger  btn-block ">Remove</button>
                            </form>
                        <a href="<?php echo e(route('user.tasks.show',$task->id)); ?>" class="btn btn-outline-warning  btn-block ml-3">Edit  </a></td>

                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php endif; ?>


            </tbody>
          </table>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.essentials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/work/Desktop/grand_finale/Internship/TaskQode/resources/views/users/tasks/index.blade.php ENDPATH**/ ?>