<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Task;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class TaskController extends Controller
{
    public function __construct() {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function dash()
    {
        //
        $id = Auth::user()->id;
        $user = User::find($id);
        $tasks = Task::where(['user_id'=>$id])->latest()->limit(4)->get();
        $dark = Task::where(['level'=>'dark'])->count();
        $secondary = Task::where(['level'=>'secondary'])->count();
        $primary = Task::where(['level'=>'primary'])->count();
        $success = Task::where(['level'=>'success'])->count();
        $warning = Task::where(['level'=>'warning'])->count();
        $danger = Task::where(['level'=>'danger'])->count();
        // $tasks = Task::where([['user_id', '=', $user->id]])->latest->get();
        // dd($tasks);
        if(isset($tasks)){
            return view('users.tasks.dashboard',compact('tasks','user','dark','secondary','primary','warning','success','danger'));
        }
    }



    public function index(){

        $id = Auth::user()->id;
        $user = User::find($id);
        $tasks = Task::where(['user_id'=>$id])->latest()->get();
        $dark = Task::where(['level'=>'dark'])->count();
        $secondary = Task::where(['level'=>'secondary'])->count();
        $primary = Task::where(['level'=>'primary'])->count();
        $success = Task::where(['level'=>'success'])->count();
        $warning = Task::where(['level'=>'warning'])->count();
        $danger = Task::where(['level'=>'danger'])->count();

        if(isset($tasks)){
            return view('users.tasks.index',compact('tasks','user','dark','secondary','primary','warning','success','danger'));
        }

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //

        $this->validator($request->all())->validate();
        // dd($request['description']);
        $tasks = new Task;
        $tasks->user_id = request('user_id');
        $tasks->title = request('title');
        $tasks->description = request('description');
        $tasks->start = request('start');
        $tasks->end = request('end');
        $tasks->level = request('level');
        $tasks->save();
            return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $user_id = Auth::user()->id;
        $user = User::find($user_id);
        $task = Task::find($id);
        $tasks = Task::where(['user_id'=>$id])->latest()->limit(4)->get();
        return view('users.tasks.show',compact('task','tasks','user'));


    }

    public function list($id){


    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $this->editvalidator($request->all())->validate();
        $user = Task::find($id);
        // dd($user);
        $input = $request->all();
        $user->update($input);
        return redirect()->route('user.tasks.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $tasks = Task::find($id);
        // dd($tasks->id);
        $tasks->delete();
         return redirect()->back();
    }

    protected function validator(array $data)
    {
        return Validator::make($data, [
            'title' => ['required', 'string', 'max:25'],
            'description' => ['required', 'string'],
            'start' => ['required'],
            'end' => ['required'],
            'level' => ['required'],
        ]);
    }

    protected function editvalidator(array $data)
    {
        return Validator::make($data, [
            'title' => ['required', 'string', 'max:25'],
            'description' => ['required', 'string'],
            'start' => ['required'],
            'end' => ['required'],
            'level' => ['required'],
        ]);
    }
}
