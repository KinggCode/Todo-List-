<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Task;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class UserController extends Controller
{

    public function __construct() {
        $this->middleware(['auth']);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //

    }







    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $user = User::find($id);
        // $tasks = $user->task;
        $task = Task::find($user);
        $user = User::find($id);



        $dark = Task::where(['level'=>'dark'])->count();
        $secondary = Task::where(['level'=>'secondary'])->count();
        $primary = Task::where(['level'=>'primary'])->count();
        $success = Task::where(['level'=>'success'])->count();
        $warning = Task::where(['level'=>'warning'])->count();
        $danger = Task::where(['level'=>'danger'])->count();
        $usercnt= Task::where(['user_id'=>$id])->count();

        $tasks = Task::where(['user_id'=>$id])->latest()->limit(4)->get();
        // dd($tasks);
        return view('users.accounts.show',compact('user','tasks','dark','secondary','primary','success','warning','usercnt','danger'));

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //

        $user = User::find($id);
        return view('users.accounts.edit',compact('user'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $this->validator($request->all())->validate();
        $user = User::find($id);
        // dd($user);
        $input = $request->all();
        $user->update($input);
        return redirect()->route('user.users.show',$user);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    protected function validator(array $data)
    {
        return Validator::make($data, [
            'name' => ['required', 'string', 'max:25'],
            'email' => ['required'],
            'password' => ['required'],
            'pin' => ['required'],
            'phone' => ['required','integer'],

        ]);
    }

}
