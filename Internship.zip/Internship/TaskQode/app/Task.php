<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class Task extends Model
{
    //
    protected $guarded = [];

    public function users(){
        return $this->belongsTo(User::class);
    }

    public function getActiveAttribute($attributes){
        return [
            0 => 'Inactive',
            1 => 'Active'
        ][$attributes];
    }


    public function scopeActive($query){
        return $query->where('status','1');
    }

    public function scopeInactive($query){
        return $query->where('status','0');
    }

    
}
