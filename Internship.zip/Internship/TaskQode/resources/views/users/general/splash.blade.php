@extends('users.essentials.splash')

@section('title', 'TaskQode - Dashboard')


@section('content')
<div class="row">

    <div class="col-lg-12 col-sm-12 col-md-12">
        <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
              <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
              <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
              <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner">
              <div class="carousel-item active">
                <img src="https://images.pexels.com/photos/3243/pen-calendar-to-do-checklist.jpg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" class="d-block w-100 slideimg" alt="...">
                <div class="carousel-caption d-none d-md-block slide-text">
                    <strong> <h2>Welcome to TaskQode</h2></strong>
                  <p>Withholding nothin</p>
                  <a href="{{ route('taskqode') }}" class="btn btn-secondary">Proceed</a>
                </div>
              </div>
              <div class="carousel-item">
                <img src="https://images.pexels.com/photos/669613/pexels-photo-669613.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" class="d-block w-100 slideimg" alt="...">
                <div class="carousel-caption d-none d-md-block slide-text">
                 <strong> <h2>Instant Notification</h2></strong>
                  <p>Instant report on to-do list & history </p>
                  <a href="{{ route('taskqode') }}" class="btn btn-secondary">Proceed</a>
                </div>
              </div>
              <div class="carousel-item">
                <img src="https://images.pexels.com/photos/636243/pexels-photo-636243.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" class="d-block w-100 slideimg" alt="...">
                <div class="carousel-caption d-none d-md-block slide-text">
                    <strong>   <h2>Create Memories</h2></strong>
                  <p>Enjoy the blogs and news</p>
                  <a href="{{ route('taskqode') }}" class="btn btn-secondary">Proceed</a>
                </div>
              </div>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
              <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
              <span class="sr-only">Next</span>
            </a>
          </div>
    </div>
</div>
@endsection
