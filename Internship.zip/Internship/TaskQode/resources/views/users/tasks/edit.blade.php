@extends('users.essentials.layout')

@section('title', 'TaskQode - Dashboard')



@section('content')



<div class="row">
    <div class="col-lg-12 col-md-12">
        <div class="card">
            <div class="card-body shadow-lg">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="card">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-lg-12 col-sm-12 col-md-12">
                                        <h4 class="my-4">To to list</h4>
                                    </div>
                                </div>


                                  <div class="row">
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <a class="btn btn-outline-info my-3 text-center">View More</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="card">
                            <div class="card-body shadow-lg">
                                <div class="row">
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <h3>Tasks Chart</h3>
                                        <div class="list-group">

                                            @if(isset($tasks))

                                            @foreach ($tasks as $task )
                                            <a href="#" class="list-group-item list-group-item-action a{{ $task->level }}">
                                                <div class="d-flex w-100 justify-content-between">
                                                  <h5 class="mb-1">{{ $task->title }}</h5>
                                                  <small>{{ $task->created_at }}</small>
                                                </div>
                                                <p class="mb-1">{{ $task->description }}</p>
                                                <small><strong><span>Start Date: </span></strong> {{ $task->start }}</small>
                                                <small><strong><span>End Date: </span></strong> {{ $task->start }}</small>
                                              </a>

                                            @endforeach


                                            @endif


                                          </div>

                                    </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


@endsection
