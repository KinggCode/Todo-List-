@extends('users.essentials.layout')

@section('title', 'TaskQode - Dashboard')

@section('message')
<div class="jumbotron jumbotron-fluid">
    <div class="container">
      <h1 class="display-4">Welcome {{ $user->name }}</h1>
      <p class="lead">To get started visit your profile for instructions. <span><a href="{{ route('user.users.show',Auth::user()->id) }}">Profile</a></span></p>
    </div>
  </div>

@endsection

@section('content')
<div class="row">
    <div class="col-lg-12">
        <div class="card my-3">
            <div class="card-body shadow-lg">

                <div class="row">
                    <div class="col-lg-12">
                        <h2 class="ml-4">TaskQode</h2>
                    </div>
                </div>
                <div class="row panel">
                    <div class="col-lg-5 col-md-5" >
                        <div class="card">
                            <div class="card-body shadow-lg">
                                <form method="POST" action="{{ route('user.tasks.store',Auth::user()->id) }}">
                                    @csrf
                                    <div class="form-group">
                                      <label for="exampleInputEmail1">Title</label>
                                      <input type="text"title name="title" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                                      @error('title')
                                      <small style="color:red;">{{ $errors->first('title') }}</small>
                                  @enderror
                                    </div>

                                    <div class="form-group">
                                        <label for="exampleFormControlSelect1">Level</label>
                                        <select class="form-control" name="level" id="exampleFormControlSelect1">
                                          <option value="primary">Not Important</option>
                                          <option value="secondary">Little Important</option>
                                          <option value="warning">Important</option>
                                          <option value="success">Very Important</option>
                                          <option value="danger">Need to achieve</option>
                                        </select>
                                      </div>

                                      <div class="form-group">
                                        <label for="exampleFormControlTextarea1">Description</label>
                                        <textarea class="form-control" name="description" id="exampleFormControlTextarea1" rows="5"></textarea>
                                        @error('description')
                                        <small style="color:red;">{{ $errors->first('description') }}</small>
                                    @enderror
                                    </div>


                            </div>
                        </div>

                    </div>

                    <div class="col-lg-7 col-md-7">
                        <div class="card">
                            <div class="card-body shadow-lg">
                                  {{-- <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="inlineCheckbox1" value="option1">
                                        <div class="danger"></div>
                                      </div>

                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="inlineCheckbox2" value="option2">
                                        <div  class="warning"> </div>
                                      </div>

                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="inlineCheckbox3" value="option3" >
                                        <div  class="danger"> </div>
                                      </div>

                                      <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="inlineCheckbox3" value="option3">
                                        <div  class="success"> </div>
                                      </div> --}}



                                      <div class="form-group">
                                        <label for="exampleInputPassword1">Start Date</label>
                                        <input type="date" name="start" class="form-control" id="exampleInputPassword1">
                                        @error('start')
                                        <small style="color:red;">{{ $errors->first('start') }}</small>
                                    @enderror
                                    </div>

                                      <div class="form-group">
                                        <label for="exampleInputPassword1">End Date</label>
                                        <input type="date" name="end" class="form-control" id="exampleInputPassword1">
                                        @error('end')
                                        <small style="color:red;">{{ $errors->first('end') }}</small>
                                    @enderror
                                    </div>

                                    <input type="hidden" name="user_id" value="{{ Auth::user()->id }}">

                                    <button type="submit" class="btn btn-primary">Submit</button>
                                  </form>
                            </div>
                        </div>

                    </div>
                </div>
            </div>


        </div>
    </div>
</div>


<div class="row">
    <div class="col-lg-12 col-md-12">
        <div class="card">
            <div class="card-body shadow-lg">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="card">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-lg-12 col-sm-12 col-md-12">
                                        <h4 class="my-4">To to list</h4>
                                    </div>
                                </div>
                                <div class="list-group">

                                    @if(isset($tasks))

                                    @foreach ($tasks as $task )
                                    <a href="{{ route('user.tasks.show',$task->id) }}" class="list-group-item list-group-item-action a{{ $task->level }}">
                                        <div class="d-flex w-100 justify-content-between">
                                          <h5 class="mb-1">{{ $task->title }}</h5>
                                          <small>{{ $task->created_at }}</small>
                                        </div>
                                        <p class="mb-1">{{ $task->description }}</p>
                                        <small><strong><span>Start Date: </span></strong> {{ $task->start }}</small>
                                        <small><strong><span>End Date: </span></strong> {{ $task->start }}</small>
                                      </a>

                                    @endforeach


                                    @endif

                                    @if(isset($tasks) !== null && isset($tasks) == null )
                                      <a class="list-group-item">No record found</a>

                                    @endif


                                  </div>

                                  <div class="row">
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <a href="{{ route('user.tasks.index') }}" class="btn btn-outline-info my-3 text-center">View More</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="card">
                            <div class="card-body shadow-lg">
                                <div class="row">
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <h3>Tasks Chart</h3>

                                        <div class="card">
                                            <div class="card-body">

                                                    <input type="hidden" id="danger" value="{{ $danger }}">
                                                    <input type="hidden" id="success" value="{{ $success }}">
                                                    <input type="hidden" id="secondary" value="{{ $secondary }}">
                                                    <input type="hidden" id="primary" value="{{ $primary }}">
                                                    <input type="hidden" id="dark" value="{{ $dark}}">
                                                    <input type="hidden" id="warning" value="{{ $warning }}">
                                                    <canvas id="tasksChart" width="100%" height="30"> </canvas>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


@endsection
