@extends('users.essentials.layout')

@section('title', 'TaskQode - Dashboard')



@section('content')

<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12">
        <div class="card">
            <div class="card-body shadow-lg">
                <div class="row">
                    <div class="col-lg-12">
                        <h3>Task</h3>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="row">
                            <div class="col-3">
                              <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                                <a class="nav-link active" id="v-pills-home-tab" data-toggle="pill" href="#v-pills-home" role="tab" aria-controls="v-pills-home" aria-selected="true">{{ $task->title }}</a>
                                <a class="nav-link" id="v-pills-profile-tab" data-toggle="pill" href="#v-pills-profile" role="tab" aria-controls="v-pills-profile" aria-selected="false">Edit</a>
                                {{-- <a class="nav-link" id="v-pills-messages-tab" data-toggle="pill" href="#v-pills-messages" role="tab" aria-controls="v-pills-messages" aria-selected="false">Messages</a>
                                <a class="nav-link" id="v-pills-settings-tab" data-toggle="pill" href="#v-pills-settings" role="tab" aria-controls="v-pills-settings" aria-selected="false">Settings</a> --}}
                                <a href="{{ route('user.tasks.dash',Auth::user()->id) }}" class="nav-link btn btn-outline-secondary my-3">Back to Tasks</a>
                              </div>
                            </div>
                            <div class="col-9">
                              <div class="tab-content" id="v-pills-tabContent">
                                <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
                                    <ul class="list-group">
                                        <li class="list-group-item"> <strong><span>Description: </span></strong>{{ $task->description }}</li>
                                        <li class="list-group-item"><strong><span>Start: </span></strong>{{ $task->start }}</li>
                                        <li class="list-group-item"><strong><span>End: </span></strong>{{ $task->end }}</li>
                                        <li class="list-group-item"><strong><span>Level: </span></strong>{{ $task->level }}</li>
                                      </ul>
                                </div>
                                <div class="tab-pane fade" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <form method="POST" action="{{ route('user.tasks.update',Auth::user()->id) }}">
                                                @method('PATCH')
                                                @csrf
                                                <div class="form-group">
                                                  <label for="exampleInputEmail1">Title</label>
                                                  <input type="text" class="form-control" name="title" value="{{ $task->title }}">
                                                </div>
                                                <div class="form-group">
                                                  <label for="exampleInputPassword1">Description</label>
                                                  <input type="text" class="form-control" name="description" value="{{ $task->description }}" >
                                                </div>
                                                <div class="form-group">
                                                    <label for="exampleInputPassword1">Start Date</label>
                                                    <input type="date" class="form-control" name="start" value="{{ $task->start }}" >
                                                  </div>
                                                  <div class="form-group">
                                                    <label for="exampleInputPassword1">End Date</label>
                                                    <input type="date" class="form-control" name="end" value="{{ $task->end }}">
                                                  </div>

                                                  <div class="form-group">
                                                    <label for="exampleFormControlSelect1">Level</label>
                                                    <select class="form-control" name="level" id="exampleFormControlSelect1">
                                                      <option value="primary">Not Important</option>
                                                      <option value="secondary">Little Important</option>
                                                      <option value="warning">Important</option>
                                                      <option value="success">Very Important</option>
                                                      <option value="danger">Need to achieve</option>
                                                    </select>
                                                  </div>
                                                  
                                                  <button type="submit" class="btn btn-warning">Edit {{ $task->title }}</button>
                                                </form>

                                        </div>

                                        <div class="col-lg-6">


                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="v-pills-messages" role="tabpanel" aria-labelledby="v-pills-messages-tab">...</div>
                                <div class="tab-pane fade" id="v-pills-settings" role="tabpanel" aria-labelledby="v-pills-settings-tab">...</div>
                              </div>
                            </div>
                          </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
