{{-- Meta Tags  --}}
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>@yield('title','TaskQode')</title>
<meta name="description" content="TaskQode">
<meta name="viewport" content="width=device-width, initial-scale=1">

{{-- External Stylesheets --}}
<link rel="stylesheet" href="/assets/css/Chart.css">
<link rel="stylesheet" href="/assets/css/style.css">
{{-- <link rel="stylesheet" href="assets/css/Chart.bundle.css"> --}}
<link rel="stylesheet" href="/assets/css/bootstrap.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Raleway:wght@100&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Raleway:wght@100;400&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Raleway:wght@100;400;900&display=swap" rel="stylesheet">

{{-- Custom Stylesheets --}}
<link rel="stylesheet" href="/assets/css/style.css">
