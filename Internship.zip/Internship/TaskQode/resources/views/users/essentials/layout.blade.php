<!doctype html>
<html  lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    @include('users.essentials.links')
</head>

<body>

    <!-- Right Panel -->
    @include('users.essentials.navbar')
    <div id="dash-panel" class="dash-panel">

        @yield('message')
        @yield('breadcrumb')

        @if (session()->has('success'))
          <div class="alert alert-success " role="alert">
            <strong>Success: </strong> <span>{{ session()->get('message') }}</span>
            </div>
          @endif

          @if(session()->has('error'))
          <div class="alert alert-danger" role="alert">
            <strong>Warning : </strong> <span>{{ session()->get('error') }}</span>
             </div>
          @endif


        @yield('content')

    </div>

   @include('users.essentials.scripts')
</body>
</html>
