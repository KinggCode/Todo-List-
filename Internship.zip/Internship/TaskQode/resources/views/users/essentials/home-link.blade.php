<div class="row">
    <div class="col-lg-12 col-md-12">
        <a  href="/" class="btn btn-outline-secondary " style="margin:2rem 2rem">  @yield('name') </a>
    </div>
</div>
