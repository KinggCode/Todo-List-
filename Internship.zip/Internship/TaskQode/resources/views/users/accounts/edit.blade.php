@extends('users.essentials.layout')

@section('title', 'TaskQode - Dashboard')


@section('content')

<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="{{ route('user.users.show',Auth::user()->id) }}">Profile</a></li>
    <li class="breadcrumb-item active" aria-current="page">{{ $user->name }}</li>
    </ol>
  </nav>

<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12">
        <div class="card">
            <div class="card-body shadow-lg">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="card">
                            <div class="card-body">
                                <form class="my-5" action="{{ route('user.users.update',Auth::user()->id)}}"  method="POST" >
                                   @method('PATCH')
                                    @csrf
                                    <div class="form-group">
                                      <label for="exampleInputEmail1">Full name</label>
                                      <input type="text" class="form-control" name="name" value="{{ $user->name ?? 'N/A'}}">
                                      @error('title')
                                      <small style="color:red;">{{ $errors->first('title') }}</small>
                                  @enderror
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Username</label>
                                        <input type="text" class="form-control" name="username" value="{{ $user->username ?? ' '}}">

                                      </div>
                                      <div class="form-group">
                                        <label for="exampleInputEmail1">Email address</label>
                                        <input type="email" class="form-control" name="email" aria-describedby="emailHelp" value="{{ $user->email ?? 'N/A'}}">
                                        <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                                        @error('email')
                                        <small style="color:red;">{{ $errors->first('email') }}</small>
                                    @enderror
                                    </div>
                                      <div class="form-group">
                                        <label for="exampleInputEmail1">Pin</label>
                                        <input type="text" class="form-control" name="pin" value="{{ $user->pin ?? '' }}">
                                        @error('pin')
                                        <small style="color:red;">{{ $errors->first('pin') }}</small>
                                    @enderror
                                    </div>
                                    <div class="form-group">
                                      <label for="exampleInputPassword1">Password</label>
                                      <input type="password" class="form-control" name="password" value="{{ $user->password ?? ''}}">
                                      @error('password')
                                      <small style="color:red;">{{ $errors->first('password') }}</small>
                                  @enderror
                                    </div>



                            </div>
                        </div>
                    </div>



                <div class="col-lg-6 col-sm-6 col-md-6">
                        <div class="form-group">
                          <label for="exampleInputEmail1">Gender</label>
                          <input type="text" class="form-control" name="gender" aria-describedby="emailHelp" value="{{ $user->gender  ?? '-'}}">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Phone</label>
                            <input type="text" class="form-control" name="phone" aria-describedby="emailHelp" value="{{ $user->phone ?? '00000000' }}">
                          </div>

                        <div class="form-group">
                            <label for="exampleInputEmail1">Country</label>
                            <input type="text" class="form-control" name="country" aria-describedby="emailHelp" value="{{ $user->country ?? '' }}">
                          </div>
                          <div class="form-group">
                            <label for="exampleInputEmail1">City</label>
                            <input type="text" class="form-control" name="city" aria-describedby="emailHelp" value="{{ $user->city ?? '' }}">
                          </div>

                          <div class="form-group">
                              <p>Last updated: {{ $user->updated_at }}</p>
                              <p>Status: Online</p>
                              <p>Access Code: Ask Admin for access</p>
                          </div>

                        <button type="submit" class="btn btn-primary">Submit</button>
                      </form>

            </div>
        </div>
    </div>
</div>

@endsection
