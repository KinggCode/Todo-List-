@extends('users.essentials.layout')

@section('title', 'TaskQode - Profile')


@section('content')

<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12">
        <div class="card">
            <div class="card-body shadow-lg">
                <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-4">
                        <div class="card">
                            <div class="card-body profile">
                                <img src="https://images.pexels.com/photos/556665/pexels-photo-556665.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" class="card-img-top rounded-circle shadow-lg shadow-primary" alt="...">
                                <div class="card-body">
                                  <h5 class="card-title">{{ $user->name }}</h5>
                                  <p class="card-text"> <strong>Username:</strong>  {{ $user->username ?? 'N/A' }}</p>
                                  <p class="card-text"> <strong>Email:</strong>  {{ $user->email ?? 'N/A' }}</p>
                                  <p class="card-text"> <strong>Gender:</strong>  {{ $user->gender ?? 'N/A' }}</p>
                                  <p class="card-text"> <strong>Phone:</strong>  {{ $user->phone ?? 'N/A' }}</p>
                                  <p class="card-text"> <strong>Access:</strong>  {{ $user->access ?? 'Not Granted' }}</p>
                                    <a href="{{ route('user.users.edit',Auth::user()->id) }}" class="ml-2">Edit Profile</a>
                                    <a href="{{  route('user.tasks.dash',Auth::user()->id)  }}" class="ml-4">Task Management</a>

                                </div>
                        </div>
                    </div>

                    <div class="col-lg-12">

                    </div>
                </div>


                <div class="col-lg-8">


                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <h3>No of tasks </h3>
                                                </div>

                                                <input type="hidden" id="user" value="{{ $usercnt }}">
                                                <canvas id="userChart" width="100%" height="30"> </canvas>
                                                 </canvas>

                                            </div>
                                        </div>
                                    </div>

                                    <div class="card my-3">
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <h3>Tasks Division</h3>
                                                </div>

                                                <input type="hidden" id="danger" value="{{ $danger }}">
                                                    <input type="hidden" id="success" value="{{ $success }}">
                                                    <input type="hidden" id="secondary" value="{{ $secondary }}">
                                                    <input type="hidden" id="primary" value="{{ $primary }}">
                                                    <input type="hidden" id="dark" value="{{ $dark}}">
                                                    <input type="hidden" id="warning" value="{{ $warning }}">
                                                    <canvas id="tasksChart" width="100%" height="30"> </canvas>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">

                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <h3 class="my-3">Recent</h3>
                                                </div>
                                            </div>
                                            <div class="list-group shadow-lg">

                                                @if(isset($tasks))

                                                @foreach ($tasks as $task )
                                                <a href="{{ route('user.tasks.show',$task->id) }}" class="list-group-item list-group-item-action a{{ $task->level }}">
                                                    <div class="d-flex w-100 justify-content-between">
                                                      <h5 class="mb-1">{{ $task->title }}</h5>
                                                      <small>{{ $task->created_at }}</small>
                                                    </div>
                                                    <p class="mb-1">{{ $task->description }}</p>
                                                    <small><strong><span>Start Date: </span></strong> {{ $task->start }}</small>
                                                    <small><strong><span>End Date: </span></strong> {{ $task->start }}</small>
                                                  </a>

                                                @endforeach



                                                @endif

                                                @if(isset($tasks) !== null && isset($tasks) == null)
                                                <a class="list-group-item">No Tasks Added</a>
                                                @endif



                                              </div>
                                              <div class="row my-3">
                                                <div class="col-lg-12">
                                                    <h3 class="mt-3">History</h3>
                                                </div>
                                            </div>
                                              <div class="list-group  shadow-lg">

                                                <a href="#" class="list-group-item list-group-item-action active">
                                                  <div class="d-flex w-100 justify-content-between">
                                                    <h5 class="mb-1">Unconstruction</h5>
                                                    <small>3 days ago</small>
                                                  </div>
                                                  <p class="mb-1">Unconstruction</p>
                                                  <small>Unconstruction</small>
                                                </a>

                                              </div>




                                </div>
                            </div>




                </div>
            </div>
        </div>
    </div>
</div>

@endsection
