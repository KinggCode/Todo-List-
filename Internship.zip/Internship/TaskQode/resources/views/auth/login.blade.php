@extends('layouts.auth')

@section('title','TaskQode - User Login')
@section('name','TaskQode')
@section('content')
@include('users.essentials.home-link')
    <div class="row">
        <div class="col-lg-6 col-md-5">
            <img src="https://images.pexels.com/photos/2495173/pexels-photo-2495173.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=500" alt="..." class="img-thumbnail border border-dark rounded-circle" style="margin-top:4rem; margin-left:5rem; width:35rem; height:35rem;">
        </div>
        <div class="col-lg-6 col-md-7">
        <div class="" style="margin-top: 6rem;">
            <div class="login-logo" >
                <h1 style="color: black;" class="has-text-weight-bold text-center mb-4">
                   TaskQode Entry
                </h1>
                <p></p>
            </div>

            <!-- Register container   -->
            <div class="login-form" style="margin-right:2rem;">
                <form method="POST" action='{{ url("/login") }}' aria-label="{{ __('Login') }}">
                    @csrf

                    <div class="form-group">
                        <label>Email address</label>
                        <input type="email" name="email" class="form-control" placeholder="Email" value="{{old('email')}}">
                        @error('email')
                        <small style="color:red;">{{ $errors->first('email') }}</small>
                    @enderror
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" name="password" class="form-control" placeholder="Password" value="{{old('password')}}">
                        @error('password')
                        <small style="color:red;">{{ $errors->first('password') }}</small>
                    @enderror
                    </div>

                    <div class="form-group">
                        <label>Pin code</label>
                        <input type="text" name="pin" class="form-control" placeholder="Pin code" value="{{old('pin')}}">
                        @error('pin')
                        <small style="color:red;">{{ $errors->first('pin') }}</small>
                    @enderror

                    </div>
                    <div class="checkbox">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="remember" id="remember" {{ old('remember') ? 'checked' : '' }}>

                            <label class="form-check-label" for="remember">
                                {{ __('Remember Me') }}
                            </label>
                        </div>
                        <label class="pull-right">
                            <a href="#">Forgotten Password?</a>
                        </label>

                    </div>
                    <button type="submit" name="user_reg_btn" class="btn btn-secondary btn-flat m-b-30 m-t-30">Sign In</button>
                    <div class="register-link m-t-15 text-center" style="margin-top: 2rem;">
                        <p>Already a member  ? <a href="{{ url('register') }}"> Sign Up Here</a></p>
                    </div>
                </form>
            </div>
            <!-- Login Container ends -->
        </div>


        </div>
    </div>

@endsection




