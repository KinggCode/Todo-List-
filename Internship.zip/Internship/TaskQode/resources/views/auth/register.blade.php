@extends('layouts.auth')

@section('title','TaskQode  - User Registration')
@section('name','TaskQode')

@section('content')
@include('users.essentials.home-link')
<div class="row">
    <div class="col-lg-6 col-md-5">
        <img src="https://images.pexels.com/photos/2495173/pexels-photo-2495173.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=500" alt="..." class="img-thumbnail border border-dark rounded-circle" style="margin-top:3rem; margin-left:5rem; width:35rem; height:35rem;">
    </div>
    <div class="col-lg-6 col-md-7">
    <div class="" style="margin-top: 2rem;">
        <div class="login-logo" >
            <h1 style="color: black;" class="has-text-weight-bold text-center mb-4">
               User Registration
            </h1>
            <p class="text-center" style="font-size: 0.8rem;">Register now, your journey begins here.</p>
        </div>

        <!-- Register container   -->
        <div class="login-form" style="margin-right:2rem;">
            <form method="POST" action="{{ url('/register') }}" aria-label="{{ __('Register') }}">
                @csrf
                <div class="form-group">
                    <label>Fullname</label>
                <input type="text" name="name" class="form-control" placeholder="Fullname" value="{{old('name')}}">
                    @error('name')
                        <small style="color:red;">{{ $errors->first('name') }}</small>
                    @enderror
                </div>
                <div class="form-group">
                    <label>Email address</label>
                    <input type="email" name="email" class="form-control" placeholder="Email" value="{{old('email')}}">
                    @error('email')
                    <small style="color:red;">{{ $errors->first('email') }}</small>
                @enderror
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" class="form-control" placeholder="Password" value="{{old('password')}}">
                    @error('password')
                    <small style="color:red;">{{ $errors->first('password') }}</small>
                @enderror
                </div>

                <div class="form-group">
                    <label>Confirm Password</label>
                    <input type="password" name="password_confirmation" class="form-control" placeholder="Password" value="{{old('password')}}">

                    @error('password')
                    <small style="color:red;">{{ $errors->first('password') }}</small>
                @enderror
                </div>

                <div class="form-group">
                    <label>Pin</label>
                    <input id="pin" type="text" class="form-control @error('pin') is-invalid @enderror" name="pin" value="{{ old('pin') }}" autocomplete="pin" autofocus>
                    @error('pin')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror

                </div>
                <div class="checkbox">
                    <label class="pull-right">
                        <a href="#">Forgotten Password?</a>
                    </label>

                </div>
                <button type="submit" name="user_reg_btn" class="btn btn-secondary btn-flat m-b-30 m-t-30">Sign Up</button>

                <div class="register-link m-t-15 text-center" style="margin-top: 2rem;">
                    <p>Already a member  ? <a href="{{ url('/login') }}"> Sign In Here</a></p>
                </div>
            </form>
        </div>
        <!-- Login Container ends -->
    </div>


    </div>
</div>



@endsection
