$(document).ready(function(){
    var ctx = document.getElementById('tasksChart').getContext('2d');
    var danger = document.getElementById('danger').value;
    var success = document.getElementById('success').value;
    var secondary = document.getElementById('secondary').value;
    var warning = document.getElementById('warning').value;
    var primary = document.getElementById('primary').value;
    var dark = document.getElementById('dark').value;

  //   console.log(active)
    var chart = new Chart(ctx, {
        // The type of chart we want to create
        type: 'bar',

        // The data for our dataset
        data: {
            labels: ['Danger', 'Success','Secondary','Warning','Primary','Dark'],
            datasets: [{
                label: 'Tasks',
                backgroundColor: ['#ff7979','#2ecc71','#7f8c8d','#f9ca24','#3498db','#2c3e50'],
                borderColor: ['#ff7979','#2ecc71','#7f8c8d','#f9ca24','#3498db','#2c3e50'],
                data: [danger, success, secondary, warning, primary, dark]
            }]
        },

        // Configuration options go here
        options: {
          legend: {
              labels: {
                  // This more specific font property overrides the global property
                  fontColor: 'black'
              }
          }
        }
    });


})




