$(document).ready(function(){
    var ctx = document.getElementById('userChart').getContext('2d');
    var user = document.getElementById('user').value;


  //   console.log(active)
    var chart = new Chart(ctx, {
        // The type of chart we want to create
        type: 'bar',

        // The data for our dataset
        data: {
            labels: ['Danger', ],
            datasets: [{
                label: 'Tasks',
                backgroundColor: ['#7f8c8d',],
                borderColor: ['#ff7979',],
                data: [user]
            }]
        },

        // Configuration options go here
        options: {
          legend: {
              labels: {
                  // This more specific font property overrides the global property
                  fontColor: 'black'
              }
          }
        }
    });


})




